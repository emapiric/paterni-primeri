/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visitor;

import concrete_element.Examination;
import concrete_element.Eyesight;
import concrete_element.Pressure;
import concrete_element.Weight;

/**
 *
 * @author Aleksandar
 */
public interface ExaminationVisitor {
    public void visit(Examination examination);
    public void visit(Weight weight);
    public void visit(Eyesight eyesight);
    public void visit(Pressure pressure);
}
