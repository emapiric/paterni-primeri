/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_visitor;

import concrete_element.Examination;
import concrete_element.Eyesight;
import concrete_element.Pressure;
import concrete_element.Weight;
import visitor.ExaminationVisitor;

/**
 *
 * @author Aleksandar
 */
public class ConcreteExaminationVisitor implements ExaminationVisitor
{
    @Override
   public void visit(Examination examination) {
      System.out.println("Full physical examination.");
   }

   @Override
   public void visit(Weight weight) {
      System.out.println("Measuring weight.");
   }

   @Override
   public void visit(Eyesight eyesight) {
      System.out.println("Checking eyesight.");
   }

   @Override
   public void visit(Pressure pressure) {
      System.out.println("Measuring pressure.");
   }
}
