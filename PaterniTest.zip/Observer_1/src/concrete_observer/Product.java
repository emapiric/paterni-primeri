/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_observer;

import observer.Observer;
import subject.Subject;

/**
 *
 * @author Aleksandar
 */
public class Product extends Observer
{
    public Product(Subject subject){
      this.subject = subject;
      this.subject.attach(this);
   }

   @Override
   public void update() {
      int product = 1;
      int[] numbers = subject.getNumbers();
      int counter = subject.getCounter();
      for (int i = 0;  i<counter; i++) 
          product*=numbers[i];
      System.out.println( "Product: " + product ); 
   }
}
