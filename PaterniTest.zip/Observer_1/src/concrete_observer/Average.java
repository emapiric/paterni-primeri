/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_observer;

import observer.Observer;
import subject.Subject;

/**
 *
 * @author Aleksandar
 */
public class Average extends Observer
{
    public Average(Subject subject){
      this.subject = subject;
      this.subject.attach(this);
   }

   @Override
   public void update() {
      int sum = 0;
      int[] numbers = subject.getNumbers();
      int counter = subject.getCounter();
      for (int i = 0;  i<counter; i++) 
          sum+=numbers[i];
      double average = (double) sum/counter;
      System.out.println( "Average: " + average ); 
   }
}
