/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_subject;

import java.util.ArrayList;
import java.util.List;
import observer.Observer;
import subject.Subject;

/**
 *
 * @author Aleksandar
 */
public class ConcreteSubject implements Subject{
    private List<Observer> observers = new ArrayList<Observer>();
    private int[] numbers = new int[10];
    int counter;

    public int[] getNumbers() {
       return numbers;
    }

    public void addNumber(int number) {
       if (counter<10) {
           this.numbers[counter] = number;
           counter++;
       }
       notifyAllObservers();
    }

    public void attach(Observer observer){
       observers.add(observer);		
    }

    public void notifyAllObservers(){
       for (Observer observer : observers) {
          observer.update();
       }
    }

    @Override
    public int getCounter() {
        return counter;
    }
}
