/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_observer.Sum;
import concrete_observer.Product;
import concrete_observer.Average;
import concrete_subject.ConcreteSubject;
import subject.Subject;

/**
 *
 * @author Aleksandar
 */
public class Client {
    public static void main(String[] args) {
      Subject subject = new ConcreteSubject();

      new Product(subject);
      new Average(subject);
      new Sum(subject);

      System.out.println("Adding number: 15");	
      subject.addNumber(15);
      System.out.println("Adding number: 2");	
      subject.addNumber(2);
      System.out.println("Adding number: 10");	
      subject.addNumber(10);
      System.out.println("Adding number: 7");	
      subject.addNumber(7);
      
   }
}
