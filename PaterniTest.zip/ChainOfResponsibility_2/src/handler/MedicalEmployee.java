/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handler;

/**
 *
 * @author Aleksandar
 */
public abstract class MedicalEmployee 
{
    public static int NURSE = 1;
    public static int DOCTOR = 2;
    public static int SURGEON = 3;
    
    protected int level;
    
    protected MedicalEmployee nextMedicalEmployee;

    public void setNextPlayer(MedicalEmployee nextMedicalEmployee) {
        this.nextMedicalEmployee = nextMedicalEmployee;
    }
    
    public String logMessage(int level, String message){
        String text = "";
      if(this.level <= level){
         text += write(message) + "\n";
      }
      if(nextMedicalEmployee != null){
         text += nextMedicalEmployee.logMessage(level, message);
      }
      return text;
   }

   abstract protected String write(String message);
}
