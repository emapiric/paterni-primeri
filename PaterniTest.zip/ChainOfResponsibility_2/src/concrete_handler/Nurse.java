/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_handler;

import handler.MedicalEmployee;

/**
 *
 * @author Aleksandar
 */
public class Nurse extends MedicalEmployee
{
    public Nurse(int level)
    {
        this.level = level;
    }

    @Override
    protected String write(String message) {
         return "Nurse took the patient's information. " + message;
    }
    
    
    
}
