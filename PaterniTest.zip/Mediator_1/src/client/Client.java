/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_colleague.Doctor;
import concrete_colleague.LabTechnician;
import concrete_mediator.Mediator;
import mediator.IMediator;


public class Client {
    public static void main(String args[])  
    { 
  
        IMediator mediator = new Mediator(); 
        Doctor doctor = new Doctor(mediator); 
        LabTechnician labTechnician = new LabTechnician(mediator); 
        mediator.registerDoctor(doctor); 
        mediator.registerLabTechnician(labTechnician); 
        doctor.getReady(); 
        labTechnician.perscribeMedicine();
        doctor.perscribeMedicine(); 
          
    } 
}
