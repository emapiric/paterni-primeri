/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_colleague;

import colleague.Command;
import mediator.IMediator;


public class LabTechnician implements Command
{
    private IMediator mediator; 
  
    public LabTechnician(IMediator mediator)  
    { 
        this.mediator = mediator; 
        mediator.setPerscriptionStatus(true); 
    } 
  
    @Override
    public void perscribeMedicine()  
    { 
        System.out.println("Perscription permission granted."); 
        mediator.setPerscriptionStatus(true); 
    } 
}
