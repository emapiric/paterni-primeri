/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_colleague;

import colleague.Command;
import mediator.IMediator;


public class Doctor implements Command{
    private IMediator mediator; 
  
    public Doctor(IMediator mediator)  
    { 
        this.mediator = mediator; 
    } 
  
    public void perscribeMedicine()  
    { 
        if (mediator.isPerscriptionOk())  
        { 
            System.out.println("Medicine perscribed."); 
            mediator.setPerscriptionStatus(true); 
        } 
        else
            System.out.println("Waiting for lab results."); 
    } 
  
    public void getReady()  
    { 
        System.out.println("Ready for perscribing medicine."); 
    } 
}
