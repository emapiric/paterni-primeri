/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_mediator;

import concrete_colleague.Doctor;
import concrete_colleague.LabTechnician;
import mediator.IMediator;


public class Mediator implements IMediator{
    private Doctor doctor; 
    private LabTechnician labTechnician; 
    public boolean perscription; 
  
    public void registerLabTechnician(LabTechnician labTechnician)  
    { 
        this.labTechnician = labTechnician; 
    } 
  
    public void registerDoctor(Doctor doctor)  
    { 
        this.doctor = doctor; 
    } 
  
    public boolean isPerscriptionOk()  
    { 
        return perscription; 
    } 
  
    @Override
    public void setPerscriptionStatus(boolean status)  
    { 
        perscription = status; 
    } 
}
