/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediator;

import concrete_colleague.Doctor;
import concrete_colleague.LabTechnician;


public interface IMediator 
{
    public void registerLabTechnician(LabTechnician runway); 
  
    public void registerDoctor(Doctor flight); 
  
    public boolean isPerscriptionOk(); 
  
    public void setPerscriptionStatus(boolean status); 
}
