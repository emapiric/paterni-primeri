/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_colleague;

import colleague.Command;
import mediator.IMediator;


public class Doctor implements Command{
    private IMediator mediator; 
  
    public Doctor(IMediator mediator)  
    { 
        this.mediator = mediator; 
    } 
  
    @Override
    public String perscribeMedicine()  
    { 
        if (mediator.isPerscriptionOk())  
        { 
            System.out.println("a");
            mediator.setPerscriptionStatus(true); 
            return "Medicine perscribed."; 
            
        } 
        return "Waiting for lab results."; 
    } 
  
    public String getReady()  
    { 
        return "Ready for perscribing medicine."; 
    } 
}
