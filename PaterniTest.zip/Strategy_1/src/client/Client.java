/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_strategy.Serbian;
import concrete_strategy.German;
import concrete_strategy.Spanish;
import concrete_strategy.English;
import context.Context;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    public static void main(String[] args) {
      Context context = new Context(new Serbian());		
      System.out.println("Serbian: " + context.executeStrategy());

      context = new Context(new English());		
      System.out.println("English: " + context.executeStrategy());

      context = new Context(new Spanish());		
      System.out.println("Spanish: " + context.executeStrategy());
      
      context = new Context(new German());		
      System.out.println("German: " + context.executeStrategy());
   }
}
