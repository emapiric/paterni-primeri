/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_strategy;

import strategy.Strategy;

/**
 *
 * @author Aleksandar
 */
public class English implements Strategy
{

    @Override
    public String speakLanguage() {
        return "Hello!";
    }
    
}
