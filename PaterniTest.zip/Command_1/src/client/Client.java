/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_command.CreateFrontendDesignCommand;
import concrete_command.DoBackendTaskCommand;
import concrete_command.InsertDataToDB;
import invoker.TeamManager;
import receiver.FrontendDeveloper;
import receiver.BackendDeveloper;

/**
 *
 * @author Aleksandar
 */
public class Client {
    public static void main(String[] args) 
    { 
        TeamManager teamManager =  new TeamManager(); 
        FrontendDeveloper frontDeveloper = new FrontendDeveloper(); 
        BackendDeveloper backDeveloper = new BackendDeveloper(); 
  
        teamManager.setCommand(new CreateFrontendDesignCommand(frontDeveloper)); 
        teamManager.createTask(); 
        teamManager.setCommand(new DoBackendTaskCommand(backDeveloper)); 
        teamManager.createTask(); 
        teamManager.setCommand(new InsertDataToDB(backDeveloper)); 
        teamManager.createTask(); 
     } 
}
