/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receiver;

/**
 *
 * @author Aleksandar
 */
public class BackendDeveloper 
{
   public void createDesign() 
    { 
        System.out.println("Backend Developer created the design for the server app."); 
    } 
    public void doTask() 
    { 
        System.out.println("Backend Developer implemented needed solutions for the server app."); 
    } 
    public void createTable() 
    { 
        System.out.println("Backend Developer created a new table in the db."); 
    } 
    public void insertData() 
    { 
        System.out.println("Backend Developer inserted data to the db."); 
    } 

}
