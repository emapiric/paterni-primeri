/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receiver;

/**
 *
 * @author Aleksandar
 */
public class FrontendDeveloper 
{
    public void createDesign() 
    { 
        System.out.println("Frontend Developer created the design for the client app."); 
    } 
    public void doTask() 
    { 
        System.out.println("Frontend Developer implemented needed solutions for the client app."); 
    } 
}
