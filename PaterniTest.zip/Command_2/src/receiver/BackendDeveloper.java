/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receiver;

/**
 *
 * @author Aleksandar
 */
public class BackendDeveloper 
{
   public String createDesign() 
    { 
        return "Backend Developer created the design for the server app."; 
    } 
    public String doTask() 
    { 
         return "Backend Developer implemented needed solutions for the server app."; 
    } 
    public String createTable() 
    { 
        return "Backend Developer created a new table in the db."; 
    } 
    public String insertData() 
    { 
         return "Backend Developer inserted data to the db."; 
    } 

}
