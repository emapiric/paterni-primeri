/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_command;

import command.Command;
import receiver.BackendDeveloper;

/**
 *
 * @author Aleksandar
 */
public class InsertDataToDB implements Command{
    BackendDeveloper backDeveloper; 
     public InsertDataToDB(BackendDeveloper backDeveloper) 
     { 
         this.backDeveloper = backDeveloper; 
     } 
     public String execute() 
     { 
         return backDeveloper.createTable() +"\n" +backDeveloper.insertData();
     } 
}
