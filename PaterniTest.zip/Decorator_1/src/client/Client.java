/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import component.Trip;
import concrete_component.Greece;
import concrete_component.Germany;
import concrete_decorator.CapitalSightseeing;
import concrete_decorator.MuseumTour;
import concrete_decorator.WineTasting;

/**
 *
 * @author Ema
 */
public class Client {
    public static void main(String args[]) 
    { 
        Trip trip1 = new Germany(); 
        System.out.println( trip1.getDescription() +  " Cost :" + trip1.getCost()); 
  
        Trip trip2 = new Greece(); 
  
        trip2 = new MuseumTour(trip2); 
  
        trip2 = new WineTasting(trip2); 
  
        System.out.println( trip2.getDescription() + " Cost :" + trip2.getCost()); 

   } 
}
