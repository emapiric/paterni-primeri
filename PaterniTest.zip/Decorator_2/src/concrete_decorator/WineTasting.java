/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_decorator;

import component.Trip;
import decorator.TourDecorator;

/**
 *
 * @author Ema
 */
public class WineTasting extends TourDecorator{
     Trip trip; 
    public WineTasting(Trip trip)  {  this.trip = trip; } 
    public String getDescription() { 
        return trip.getDescription() + ", wine tasting tour "; 
    } 
    public int getCost()  {  return 70 + trip.getCost(); } 
}
