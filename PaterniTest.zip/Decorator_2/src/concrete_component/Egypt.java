/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_component;

import component.Trip;

/**
 *
 * @author Ema
 */
public class Egypt extends Trip{
    public Egypt() { description = "Egypt"; } 
    public int getCost() {  return 300;  } 
}
