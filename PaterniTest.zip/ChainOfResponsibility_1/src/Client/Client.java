/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import concrete_handler.Nurse;
import concrete_handler.Surgeon;
import concrete_handler.Doctor;
import handler.MedicalEmployee;

/**
 *
 * @author Aleksandar
 */
public class Client 
{
    private static MedicalEmployee getChainOfMedicalEmployees(){

      Nurse n = new Nurse(MedicalEmployee.NURSE);
      Doctor d = new Doctor(MedicalEmployee.DOCTOR);
      Surgeon s = new Surgeon(MedicalEmployee.SURGEON);

      n.setNextPlayer(d);
      d.setNextPlayer(s);

      return n;	
   }
    
    public static void main(String[] args) {
        MedicalEmployee medicalEmployeeChain = getChainOfMedicalEmployees();

      medicalEmployeeChain.logMessage(MedicalEmployee.NURSE, 
         "She added it to the patient's file.");

      medicalEmployeeChain.logMessage(MedicalEmployee.DOCTOR, 
         "He prescribed medicine for him.");

      medicalEmployeeChain.logMessage(MedicalEmployee.SURGEON, 
         "He put a bandage on the wound.");
    }
}
