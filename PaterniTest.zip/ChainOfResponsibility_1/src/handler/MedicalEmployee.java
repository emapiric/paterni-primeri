/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handler;

/**
 *
 * @author Aleksandar
 */
public abstract class MedicalEmployee 
{
    public static int NURSE = 1;
    public static int DOCTOR = 2;
    public static int SURGEON = 3;
    
    protected int level;
    
    protected MedicalEmployee nextMedicalEmployee;

    public void setNextPlayer(MedicalEmployee nextMedicalEmployee) {
        this.nextMedicalEmployee = nextMedicalEmployee;
    }
    
    public void logMessage(int level, String message){
      if(this.level <= level){
         write(message);
      }
      if(nextMedicalEmployee !=null){
         nextMedicalEmployee.logMessage(level, message);
      }
   }

   abstract protected void write(String message);
}
